<?php namespace Arcanedev\NoCaptcha\Exceptions;

/**
 * Class ApiException
 * @package Arcanedev\NoCaptcha\Exceptions
 */
class ApiException extends Exception {}
