<?php namespace Arcanedev\NoCaptcha\Exceptions;

/**
 * Class Exception
 * @package Arcanedev\NoCaptcha\Exceptions
 */
class Exception extends \Exception {}
