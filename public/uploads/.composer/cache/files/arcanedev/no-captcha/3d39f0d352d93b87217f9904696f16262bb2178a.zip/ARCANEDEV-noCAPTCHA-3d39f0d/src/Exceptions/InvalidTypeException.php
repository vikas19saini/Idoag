<?php namespace Arcanedev\NoCaptcha\Exceptions;

/**
 * Class InvalidTypeException
 * @package Arcanedev\NoCaptcha\Exceptions
 */
class InvalidTypeException extends Exception {}
