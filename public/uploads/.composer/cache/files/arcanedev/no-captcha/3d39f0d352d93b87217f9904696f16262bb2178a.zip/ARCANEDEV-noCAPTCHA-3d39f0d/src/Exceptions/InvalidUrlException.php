<?php namespace Arcanedev\NoCaptcha\Exceptions;

/**
 * Class InvalidUrlException
 * @package Arcanedev\NoCaptcha\Exceptions
 */
class InvalidUrlException extends Exception {}
