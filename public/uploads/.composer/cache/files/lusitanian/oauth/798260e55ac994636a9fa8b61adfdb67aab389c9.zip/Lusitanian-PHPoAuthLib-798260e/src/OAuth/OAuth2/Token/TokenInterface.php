<?php

namespace OAuth\OAuth2\Token;

use OAuth\Common\Token\TokenInterface as BaseTokenInterface;

interface TokenInterface extends BaseTokenInterface
{
}
