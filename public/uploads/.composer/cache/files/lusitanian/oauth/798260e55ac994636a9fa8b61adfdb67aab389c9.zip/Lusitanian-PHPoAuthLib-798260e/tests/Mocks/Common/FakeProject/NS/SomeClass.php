<?php

namespace FakeProject\NS;

class SomeClass
{
    public function isLoaded()
    {
        return true;
    }
}
