# Closures

| Method  | Closure class |
| ------------- |-------------|
| create()      | Maatwebsite\Excel\Writers\LaravelExcelWriter |
| load()     | Maatwebsite\Excel\Readers\LaravelExcelReader    |
| batch | Maatwebsite\Excel\Readers\Batch     |
| sheet() | Maatwebsite\Excel\Classes\LaravelExcelWorksheet     |
| cells() | Maatwebsite\Excel\Writers\CellWriter     |
| row() | Maatwebsite\Excel\Writers\CellWriter    |