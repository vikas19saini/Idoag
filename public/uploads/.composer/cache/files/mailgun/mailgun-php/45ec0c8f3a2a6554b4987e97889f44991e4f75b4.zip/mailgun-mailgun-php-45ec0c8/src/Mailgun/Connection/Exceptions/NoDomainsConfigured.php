<?php
namespace Mailgun\Connection\Exceptions;

class NoDomainsConfigured extends \Exception{}
