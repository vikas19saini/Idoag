<?php
namespace Mailgun\Messages\Exceptions;

class InvalidParameter extends \Exception{}
