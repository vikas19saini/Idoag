ChangeLog
=========

1.0.1 (2015-04-28)
------------------

* #4: Using php-cs-fixer to automatically enforce conding standards.
* #5: Resolving to and building `mailto:` urls were not correctly handled.


1.0.0 (2015-01-27)
------------------

* Added a `normalize` function.
* Added a `buildUri` function.
* Fixed a bug in the `resolve` when only a new fragment is specified.

San José, CalConnect XXXII release!

0.0.1 (2014-11-17)
------------------

* First version!
* Source was lifted from sabre/http package.
* Provides a `resolve` and a `split` function.
* Requires PHP 5.4.8 and up.
